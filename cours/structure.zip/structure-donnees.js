/*
1-Reconnaitre la structure (tableau, objet, chaine, nombre...)
2-Visualiser la structure mentalement
3-savoir avec la boucle FOR parcourir les tableaux de
 par pas de 1, 2 voire plus,
du plus petit au plus grand et inversément
*/
/*
let var1 = [1, 2, 3, 4, 5, 6]
let var2 = [
    "Toto",//var2[0]
    "Jean",//var2[1]
    "Dupont"//var2[2]
]
let var3 = [
    { nom: "Jean", age: 23 },// var3[0]
    { nom: "Sophie", age: 30 },// var3[1]
    { nom: "Jacques", age: 12 }// var3[2]
]


let var4 = [
    ["Renault", "Peugeot"],//var4[0]
    ["Audi", "BMW"],//var4[1]
    ["Fiat", "Ferrari"]//var4[2]
]

let obj = { nom: "Jean", age: 23 }
let propriete = 'age'
// console.log(obj[propriete])// plus flexible
// console.log(obj.nom)

debugger
for (let i = 0; i < var4.length; i++) {
    console.log(var4[i])
}*/