(() => {
    const draggables = document.querySelectorAll('.draggable');
    const dropzone = document.getElementById('dropzone');
    const palette = document.getElementById('palette');

    let direction = null
    // contient le contexte lors du drag, l'élément,position, parent, et sibling
    let dragging = null;
    // lancé par l'event listener mousedown dans namespace global
    function startDrag(node, x, y) {
        console.log("start Drag")
        direction = direction === "out" ? "in" : "out"

        const rect = node.getBoundingClientRect();
        const offsetX = x - rect.left;
        const offsetY = y - rect.top;

        dragging = {
            node,
            offsetX,
            offsetY,
            parent: node.parentNode,
            next: node.nextSibling
        };

        node.style.position = 'fixed';
        node.style.zIndex = 1000;
        moveDrag(x, y);
        document.body.style.cursor = 'grabbing';
    }

    // lancé par startDrag et l'eventlistener mousedown
    function moveDrag(x, y) {
        console.log("moveDrag")
        if (!dragging) return;
        dragging.node.style.left = (x - dragging.offsetX) + 'px';
        dragging.node.style.top = (y - dragging.offsetY) + 'px';
    }

    function endDrag(x, y) {
        if (!dragging) return;
        const node = dragging.node;
        let a = dropzone.getBoundingClientRect()
        let b = palette.getBoundingClientRect()
        console.log("dropzone", a)
        console.log("palette", b)

        const dzRect = direction === "out" ? dropzone.getBoundingClientRect() : palette.getBoundingClientRect()



        // détecte si l'élément est au-dessus de la cible
        const isOver = x >= dzRect.left && x <= dzRect.right &&
            y >= dzRect.top && y <= dzRect.bottom;
        console.log("end drag", dzRect)

        node.style.position = '';
        node.style.left = '';
        node.style.top = '';
        node.style.zIndex = '';
        document.body.style.cursor = '';

        if (isOver) {
            if (direction === "out") {
                dropzone.appendChild(node);
            } else {
                palette.appendChild(node);

            }
        } else {
            // retour à la position initiale
            if (dragging.next) {
                dragging.parent.insertBefore(node, dragging.next);
            } else {
                dragging.parent.appendChild(node);
            }
        }
        dragging = null;
        direction = null;
    }

    // Écouteurs souris
    document.addEventListener('mousedown', e => {
        const target = e.target.closest('.draggable');
        if (!target) return;
        e.preventDefault();
        startDrag(target, e.clientX, e.clientY);

        const onMove = ev => moveDrag(ev.clientX, ev.clientY);
        const onUp = ev => {
            endDrag(ev.clientX, ev.clientY);
            window.removeEventListener('mousemove', onMove);
            window.removeEventListener('mouseup', onUp);
        };
        // on ajoute dans l'eventlistener deux autre listener pour détecter 
        // movement de souris et relache bouton
        window.addEventListener('mousemove', onMove);
        window.addEventListener('mouseup', onUp);
    });
})();
