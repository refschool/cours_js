let secondes = 0
console.log('toto' + secondes);



// let handle = setInterval(function () {
//     console.log("Nombre de secondes écoulées : ", secondes++);

// }, 1000);


// setTimeout(function () {
//     clearInterval(handle)
// }, 5000)
