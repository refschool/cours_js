(() => {
    const draggables = document.querySelectorAll('.draggable');
    const dropzones = document.querySelectorAll('.dropzone');

    // Démarrage du drag
    draggables.forEach(el => {

        console.log(el.parentNode)
        const obj = { id: el.id, parent: el.parentNode }
        el.addEventListener('dragstart', e => {
            e.dataTransfer.setData('application/json', JSON.stringify(obj)); // stocke l'id
            e.dataTransfer.effectAllowed = 'move'; // type de curseur
        });
    });

    dropzones.forEach(zone => {
        // Autorise le drop
        zone.addEventListener('dragover', e => {
            e.preventDefault(); // indispensable
            e.dataTransfer.dropEffect = 'move';
            zone.classList.add('over');
        });

        zone.addEventListener('dragleave', () => {
            zone.classList.remove('over');
        });

        // Drop effectif
        zone.addEventListener('drop', e => {
            e.preventDefault();
            zone.classList.remove('over');

            const obj = JSON.parse(e.dataTransfer.getData('application/json'));
            const id = obj.id
            const draggedEl = document.getElementById(id);

            if (draggedEl) {
                zone.appendChild(draggedEl); // déplace l’élément
                console.log(id, "ancien parent ", obj.parent, " dans la zone :", zone.getAttribute('id'))
            }
        });
    });
})();
